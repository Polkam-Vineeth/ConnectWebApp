module.exports= {
  images : {
    dangerouslyAllowSVG: true,
    domains: ["rb.gy","cdni.iconscout.com", "images.seattletimes.com"],
  },
};
